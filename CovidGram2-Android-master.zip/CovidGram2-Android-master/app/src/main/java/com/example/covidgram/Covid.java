package com.example.covidgram;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Covid extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_covid);
    }
}